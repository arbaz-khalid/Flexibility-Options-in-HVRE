# solar_analysis_script.py

import logging
import pandas as pd
import numpy as np
import plotly.graph_objects as go

# ----------------------------
# Logging Configuration
# ----------------------------
logging.basicConfig(level=logging.ERROR)  # Use DEBUG for detailed logs
logger = logging.getLogger(__name__)

# ----------------------------
# System Parameters
# ----------------------------
INITIAL_NUM_PANELS = 1000      # Default number of PV panels
INITIAL_NUM_TURBINES = 1      # Default number of wind turbines
BATTERY_CAPACITY_PER_UNIT = 57 # kWh per battery
CONVERTER_EFFICIENCY = 0.9     # 90% efficiency
INITIAL_SOC = 0                # Initial SOC (as %)

# ----------------------------
# BatterySOCTracker Class
# ----------------------------
class BatterySOCTracker:
    """
    Tracks and computes the battery State of Charge (SOC) across multiple dates.
    """
    
    def __init__(self, initial_soc=50, start_date='2019-01-01'):
        """
        Initialize the battery SOC tracker with a default or custom SOC.
        """
        self.battery_soc_tracking = {}
        self.initialize_battery_soc(initial_soc, start_date)

    def initialize_battery_soc(self, initial_soc=50, start_date='2019-01-01'):
        """
        Reset the tracking dictionary and set the SOC for the start date.
        """
        self.battery_soc_tracking = {}
        self.battery_soc_tracking[pd.Timestamp(start_date)] = initial_soc
        logger.info("Initialized Battery SOC at %s%% on %s.", initial_soc, start_date)

    def get_battery_soc(self, date: pd.Timestamp, initial_soc: float = 50) -> float:
        """
        Return the battery SOC for a given date if available;
        otherwise return the supplied initial SOC.
        """
        return self.battery_soc_tracking.get(date, initial_soc)

    def update_battery_soc(self, date: pd.Timestamp, soc: float):
        """
        Update or set the battery SOC for a specific date.
        """
        self.battery_soc_tracking[date] = soc
        logger.info("Updated Battery SOC on %s to %s%%.", date.strftime('%Y-%m-%d'), soc)

    def reset_soc_from_date(self, start_date: pd.Timestamp):
        """
        Remove any SOC entries from start_date onward.
        """
        keys_to_remove = [d for d in self.battery_soc_tracking if d >= start_date]
        for d in keys_to_remove:
            del self.battery_soc_tracking[d]
        logger.info("Reset SOC tracking from %s onward.", start_date.strftime('%Y-%m-%d'))

    def compute_soc_up_to_date(
        self, 
        merged_data: pd.DataFrame, 
        selected_date: pd.Timestamp, 
        num_panels: int, 
        num_turbines: int, 
        num_batteries: int, 
        initial_soc: float, 
        battery_capacity_per_unit: float, 
        converter_efficiency: float, 
        start_date: pd.Timestamp = None
    ):
        """
        Compute SOC values up to the selected_date. Optionally, recompute from a given start_date.
        Now uses BOTH PV + Wind for total production.
        """
        battery_capacity = battery_capacity_per_unit * num_batteries
        sorted_dates = merged_data.index.normalize().unique().sort_values()

        for current_date in sorted_dates:
            if current_date > selected_date:
                break  # stop once we pass the date of interest

            already_computed = (current_date in self.battery_soc_tracking)
            within_reset_range = (start_date and current_date >= start_date)
            if already_computed and not within_reset_range:
                continue

            # Get SOC from previous day or default
            previous_day = current_date - pd.Timedelta(days=1)
            soc = self.get_battery_soc(previous_day, initial_soc=initial_soc)

            # Gather that day's data; handle missing
            try:
                daily_data = merged_data.loc[current_date]
            except KeyError:
                logger.warning("No data for %s. Setting consumption/production to zero.", current_date)
                daily_data = pd.DataFrame(
                    {
                        'Consumption_kWh':[0]*24,
                        'PV_Production_kWh':[0]*24,
                        'Wind_Production_kWh':[0]*24
                    },
                    index=pd.date_range(current_date, periods=24, freq='H')
                )

            if isinstance(daily_data, pd.Series):
                daily_data = daily_data.to_frame().T

            # Ensure 24-hour data
            if daily_data.shape[0] != 24:
                logger.warning("Expected 24 hours but found %d for %s.", daily_data.shape[0], current_date)
                daily_data = daily_data.reindex(
                    pd.date_range(start=current_date, periods=24, freq='H'), 
                    fill_value=0
                )

            # Compute battery usage hour by hour
            for hour in range(24):
                consumption = daily_data.iloc[hour]['Consumption_kWh']
                # Combine solar + wind for total generation
                pv_hour   = daily_data.iloc[hour]['PV_Production_kWh']
                wind_hour = daily_data.iloc[hour]['Wind_Production_kWh']
                total_production = pv_hour + wind_hour

                if total_production >= consumption:
                    # There's some excess after meeting consumption
                    excess = total_production - consumption
                    if (num_batteries > 0) and (soc < 100):
                        # Attempt to charge
                        charge = min(excess * converter_efficiency, (100 - soc) / 100 * battery_capacity)
                        soc += (charge / battery_capacity) * 100
                else:
                    # There's a deficit
                    deficit = consumption - total_production
                    if (num_batteries > 0) and (soc > 0):
                        # Attempt to discharge as long as there's some charge
                        discharge = min(deficit, (soc / 100) * battery_capacity)
                        soc -= (discharge / battery_capacity) * 100

                # Keep SOC in 0–100 range
                soc = max(0, min(100, soc))

            # Update SOC for this day
            self.update_battery_soc(current_date, soc)

    # ----------------------------
    # Data Loading Functions
    # ----------------------------
    def load_city_consumption(
        self,
        consumption_file_path: str,
        consumption_sep: str = ';',
        consumption_date_col: str = 'Date',
        consumption_time_col: str = 'Heures',
        consumption_value_col: str = 'Consommation(kWh)'
    ) -> pd.Series:
        """
        Load city consumption from a CSV, parse the datetime, and resample to hourly kWh.
        """
        logger.info("Loading consumption data from %s...", consumption_file_path)
        try:
            data = pd.read_csv(consumption_file_path, sep=consumption_sep)
            logger.debug("Consumption data loaded successfully.")
        except FileNotFoundError as err:
            logger.error("File not found: %s", consumption_file_path)
            raise err
        except Exception as err:
            logger.error("Error reading consumption file %s: %s", consumption_file_path, err)
            raise err

        # Convert Date + Time to a single Datetime column
        data['Datetime'] = pd.to_datetime(
            data[consumption_date_col] + ' ' + data[consumption_time_col],
            format='%Y/%m/%d %H:%M',
            errors='coerce'
        )
        data.dropna(subset=['Datetime'], inplace=True)
        data.set_index('Datetime', inplace=True)

        # Clean the consumption column
        data[consumption_value_col] = pd.to_numeric(
            data[consumption_value_col].replace('ND', np.nan), 
            errors='coerce'
        )
        data[consumption_value_col].fillna(0, inplace=True)

        # Resample to hourly
        consumption_hourly = data[consumption_value_col].resample('H').sum()
        consumption_hourly.rename('Consumption_kWh', inplace=True)

        logger.info("Consumption data loaded and resampled to hourly intervals.")
        logger.debug(f"Consumption data sample:\n{consumption_hourly.head()}")
        return consumption_hourly

    def load_city_pv_production(
        self,
        pv_file_path: str,
        consumption_start_date: str,
        consumption_end_date: str,
        sep: str = ',',
        time_start_col: str = 'time',
        time_end_col: str = 'local_time',
        electricity_col: str = 'electricity'
    ) -> pd.Series:
        """
        Load and filter PV production data to match the consumption date range.
        """
        logger.info("Loading PV production data from %s...", pv_file_path)
        try:
            pv_data = pd.read_csv(pv_file_path, sep=sep)
            logger.debug("PV production data loaded successfully.")
        except FileNotFoundError as err:
            logger.error("File not found: %s", pv_file_path)
            raise err
        except Exception as err:
            logger.error("Error reading PV production file %s: %s", pv_file_path, err)
            raise err

        # Rename columns for consistency
        pv_data.rename(columns={
            time_start_col: 'Time_Start',
            time_end_col: 'Time_End',
            electricity_col: 'PV_Production_kWh'
        }, inplace=True)

        if 'PV_Production_kWh' not in pv_data.columns:
            logger.error("'PV_Production_kWh' column not found after renaming.")
            raise KeyError("Column 'PV_Production_kWh' not found in PV production data.")

        # Convert to datetime
        pv_data['Time_Start'] = pd.to_datetime(
            pv_data['Time_Start'], 
            format='%Y-%m-%d %H:%M', 
            errors='coerce'
        )
        pv_data.dropna(subset=['Time_Start'], inplace=True)
        pv_data.set_index('Time_Start', inplace=True)

        # Drop any leftover columns not needed
        if 'Time_End' in pv_data.columns:
            pv_data.drop(columns=['Time_End'], inplace=True)

        # Fill missing production with 0
        pv_data['PV_Production_kWh'].fillna(0, inplace=True)

        # Clip the data to consumption date range
        pv_production = pv_data['PV_Production_kWh'][
            (pv_data.index >= consumption_start_date) & (pv_data.index <= consumption_end_date)
        ]

        logger.info("PV production data loaded and filtered to the date range.")
        logger.debug(f"PV production data sample:\n{pv_production.head()}")
        return pv_production

    def load_city_wind_production(
        self,
        wind_file_path: str,
        consumption_start_date: str,
        consumption_end_date: str,
        sep: str = ',',
        time_start_col: str = 'time',
        time_end_col: str = 'local_time',
        electricity_col: str = 'wind_electricity'
    ) -> pd.Series:
        """
        Load and filter Wind production data to match the consumption date range.
        """
        logger.info("Loading wind production data from %s...", wind_file_path)
        try:
            wind_data = pd.read_csv(wind_file_path, sep=sep)
            logger.debug("Wind production data loaded successfully.")
        except FileNotFoundError as err:
            logger.error("File not found: %s", wind_file_path)
            raise err
        except Exception as err:
            logger.error("Error reading wind production file %s: %s", wind_file_path, err)
            raise err

        # Rename columns for consistency
        wind_data.rename(columns={
            time_start_col: 'Time_Start',
            time_end_col: 'Time_End',
            electricity_col: 'Wind_Production_kWh'
        }, inplace=True)

        if 'Wind_Production_kWh' not in wind_data.columns:
            logger.error("'Wind_Production_kWh' column not found after renaming.")
            raise KeyError("Column 'Wind_Production_kWh' not found in wind production data.")

        # Convert to datetime
        wind_data['Time_Start'] = pd.to_datetime(
            wind_data['Time_Start'], 
            format='%m/%d/%Y %H:%M', 
            errors='coerce'
        )
        wind_data.dropna(subset=['Time_Start'], inplace=True)
        wind_data.set_index('Time_Start', inplace=True)

        # Drop any leftover columns not needed
        if 'Time_End' in wind_data.columns:
            wind_data.drop(columns=['Time_End'], inplace=True)

        # Fill missing production with 0
        wind_data['Wind_Production_kWh'].fillna(0, inplace=True)

        # Clip the data to consumption date range
        wind_production = wind_data['Wind_Production_kWh'][
            (wind_data.index >= consumption_start_date) & (wind_data.index <= consumption_end_date)
        ]

        logger.info("Wind production data loaded and filtered to the date range.")
        logger.debug(f"Wind production data sample:\n{wind_production.head()}")
        return wind_production

    def merge_city_data(
        self,
        consumption: pd.Series,
        pv_production: pd.Series,
        wind_production: pd.Series,  # Now handle wind as well
        num_panels: int,
        num_turbines: int
    ) -> pd.DataFrame:
        """
        Merge consumption and scaled PV + Wind production into a single DataFrame.
        """
        logger.info("Merging consumption, PV production, and wind production data.")

        # Scale PV + Wind by their respective counts
        pv_total   = pv_production * num_panels
        wind_total = wind_production * num_turbines

        # Verify scaling
        logger.debug(f"Scaling PV Production by {num_panels} panels.")
        logger.debug(f"Scaling Wind Production by {num_turbines} turbines.")

        # Log sample scaled values
        logger.debug(f"Sample PV Production after scaling:\n{pv_total.head()}")
        logger.debug(f"Sample Wind Production after scaling:\n{wind_total.head()}")

        merged_df = pd.DataFrame({
            'Consumption_kWh': consumption,
            'PV_Production_kWh': pv_total,
            'Wind_Production_kWh': wind_total
        })
        merged_df.fillna(0, inplace=True)

        logger.info("Merging complete (PV + Wind included).")
        logger.debug(f"Merged data sample:\n{merged_df.head()}")
        return merged_df

# Instantiate a single global tracker to be reused
soc_tracker = BatterySOCTracker(initial_soc=INITIAL_SOC, start_date='2019-01-01')

# ----------------------------
# Update Graph Function
# ----------------------------
def update_graph(
    num_panels: int,
    num_turbines: int,
    num_batteries: int,
    selected_date: str,
    city_merged_data: pd.DataFrame,
    soc_tracker: BatterySOCTracker,
    initial_num_panels: int,
    initial_num_turbines: int,
    initial_soc: float,
    battery_capacity_per_unit: float,
    converter_efficiency: float
):
    """
    Generate a Plotly figure and a SOC message for the selected date,
    now combining solar + wind production.
    """
    selected_date_ts = pd.Timestamp(selected_date)

    # Attempt to get data for this date
    try:
        daily_data = city_merged_data.loc[selected_date_ts.strftime('%Y-%m-%d')]
        logger.debug(f"Retrieved data for {selected_date}.")
    except KeyError:
        msg = f"[Error] No data available for the selected date: {selected_date}"
        logger.error(msg)
        return None, msg

    if daily_data.empty:
        msg = f"[Warning] No data available for the selected date: {selected_date}"
        logger.warning(msg)
        return None, msg

    # Ensure daily_data is a DataFrame with 24 rows
    if isinstance(daily_data, pd.Series):
        daily_data = daily_data.to_frame().T

    if daily_data.shape[0] != 24:
        logger.warning("Expected 24 hours but found %d for %s.", daily_data.shape[0], selected_date)
        daily_data = daily_data.reindex(
            pd.date_range(start=selected_date_ts, periods=24, freq='H'),
            fill_value=0
        )

    # Calculate scaled PV + scaled Wind
    pv_scaling   = num_panels / initial_num_panels if initial_num_panels > 0 else 0
    wind_scaling = num_turbines / initial_num_turbines if initial_num_turbines > 0 else 0

    logger.debug(f"PV Scaling Factor: {pv_scaling}")
    logger.debug(f"Wind Scaling Factor: {wind_scaling}")

    raw_pv   = daily_data['PV_Production_kWh'].values
    raw_wind = daily_data['Wind_Production_kWh'].values

    daily_pv   = raw_pv   * pv_scaling
    daily_wind = raw_wind * wind_scaling

    logger.debug(f"Daily PV Production: {daily_pv}")
    logger.debug(f"Daily Wind Production: {daily_wind}")

    # Retrieve previous day's SOC or default
    previous_day = selected_date_ts - pd.Timedelta(days=1)
    battery_soc = soc_tracker.get_battery_soc(
        previous_day,
        initial_soc=(initial_soc if previous_day >= pd.Timestamp('2019-01-01') else 0)
    )

    # Battery parameters
    battery_capacity = battery_capacity_per_unit * num_batteries

    # Tracking arrays
    energy_charged = []
    energy_discharged = []
    unmet_demand = []
    excess_energy = []
    hour_list = list(range(24))

    # Hour-by-hour logic (using solar + wind together)
    for hour in hour_list:
        consumption = daily_data.iloc[hour]['Consumption_kWh']
        pv_production_hour   = daily_pv[hour] if hour < len(daily_pv) else 0
        wind_production_hour = daily_wind[hour] if hour < len(daily_wind) else 0

        total_generation = pv_production_hour + wind_production_hour

        if total_generation >= consumption:
            # EXCESS scenario
            excess = total_generation - consumption
            if num_batteries > 0 and battery_soc < 100:
                charge = min(
                    excess * converter_efficiency,
                    (100 - battery_soc) / 100 * battery_capacity
                )
                energy_charged.append(charge)
                battery_soc += (charge / battery_capacity) * 100
                # Residual excess after charging
                if converter_efficiency > 0:
                    remainder = excess - (charge / converter_efficiency)
                else:
                    remainder = excess
                excess_energy.append(remainder)
                logger.debug(f"Hour {hour}: Charged {charge} kWh, Excess after charging {remainder} kWh.")
            else:
                energy_charged.append(0)
                excess_energy.append(excess)
                logger.debug(f"Hour {hour}: No charging. Excess {excess} kWh.")
            energy_discharged.append(0)
            unmet_demand.append(0)

        else:
            # DEFICIT scenario
            deficit = consumption - total_generation
            if num_batteries > 0 and battery_soc > 0:
                discharge = min(
                    deficit,
                    (battery_soc / 100) * battery_capacity
                )
                energy_discharged.append(discharge)
                battery_soc -= (discharge / battery_capacity) * 100
                unmet_demand.append(deficit - discharge)
                logger.debug(f"Hour {hour}: Discharged {discharge} kWh, Unmet demand {deficit - discharge} kWh.")
            else:
                energy_discharged.append(0)
                unmet_demand.append(deficit)
                logger.debug(f"Hour {hour}: No discharging. Unmet demand {deficit} kWh.")
            energy_charged.append(0)
            excess_energy.append(0)

        # Ensure SOC is in [0, 100]
        battery_soc = max(0, min(100, battery_soc))

    # Update the SOC tracker
    soc_tracker.update_battery_soc(selected_date_ts, battery_soc)

    # Build the Plotly figure
    fig = go.Figure()

    # Show solar production in one bar trace
    fig.add_trace(
        go.Bar(
            x=hour_list,
            y=daily_pv,
            name='Solar PV (kWh)',
            marker_color='orange'
        )
    )

    # Show wind production in another bar trace
    fig.add_trace(
        go.Bar(
            x=hour_list,
            y=daily_wind,
            name='Wind (kWh)',
            marker_color='lightblue'
        )
    )

    # Show unmet demand
    fig.add_trace(
        go.Bar(
            x=hour_list,
            y=unmet_demand,
            name='Unmet Demand (kWh)',
            marker_color='red'
        )
    )

    # Show energy charged to battery
    if num_batteries > 0:
        fig.add_trace(
            go.Bar(
                x=hour_list,
                y=[-val for val in energy_charged],  # Already negative
                name='Energy Charged to Battery (kWh)',
                marker_color='green'
            )
        )
        # Show energy discharged from battery
        fig.add_trace(
            go.Bar(
                x=hour_list,
                y=energy_discharged,
                name='Energy Discharged (kWh)',
                marker_color='purple'
            )
        )

    # Show excess energy on the negative side
    fig.add_trace(
        go.Bar(
            x=hour_list,
            y=[-val for val in excess_energy],  # Negate excess energy
            name='Excess Energy (kWh)',
            marker_color='cyan'
        )
    )

    # Show electricity demand as a line
    fig.add_trace(
        go.Scatter(
            x=hour_list,
            y=daily_data['Consumption_kWh'].values,
            mode='lines+markers',
            name='Electricity Demand (kWh)',
            line=dict(color='blue', dash='dash')
        )
    )

    fig.update_layout(
        title=f'Solar + Wind Production, Battery Usage, and Demand on {selected_date_ts.strftime("%Y-%m-%d")}',
        xaxis_title='Hour of the Day',
        yaxis_title='Energy (kWh)',
        xaxis=dict(
            tickvals=hour_list,
            ticktext=[f'{h}:00' for h in hour_list]
        ),
        template='plotly_white',
        barmode='relative',  # Allows for positive and negative bars
        height=600
    )

    # Create an SOC message
    soc_message = (
        f"State of Charge at the end of {selected_date_ts.strftime('%Y-%m-%d')}: "
        f"{battery_soc:.2f}%"
    )

    logger.info(f"Generated plot for {selected_date} with SOC: {battery_soc:.2f}%.")
    
    return fig, soc_message

